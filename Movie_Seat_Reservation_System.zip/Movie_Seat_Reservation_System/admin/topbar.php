<nav class="navbar navbar-light fixed-top " style="background-color: #e3f2fd;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
	  	<div class="col-md-2 float-right">
	  		<a href="ajax.php?action=logout"><?php echo $_SESSION['login_name'] ?> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav>